//--------------------------------------------------------------
// File     : main.h
//--------------------------------------------------------------

#ifndef MAIN_H_   
#define MAIN_H_ 

//--------------------------------------------------------------
// Includes
//--------------------------------------------------------------
#include <string.h>
#include <stdio.h>
#include <stdlib.h> 
#include <stdarg.h>
#include <math.h>

#include "includes.h"
#include "stm32f4xx.h"
#include "stm32f4xx_conf.h"
#include "stm32f4xx_gpio.h"
#include "stm32f4xx_rcc.h"
#include "stm32f4xx_syscfg.h"
#include "stm32f4xx_pwr.h"
#include "stm32f4xx_usart.h"
#include "misc.h"
#include "stm32_ub_vga_screen.h"

#include "uart.h"
#include "delay.h"

// Include API
#include "VGA_draw.h"
#include "VGA_io.h"

/** commandType. */
typedef enum {
    NONE,
    LIJN,
    ELLIPSE,
    RECHTHOEK,
    DRIEHOEK,
    TEKST,
    BITMAP,
    CLEARSCHERM,
    SETERRORLEVEL,
    WACHT 

} commandType;

// Include demo app
#include "front_layer.h"
#include "logic_layer.h"
#include "io_layer.h"




#endif // MAIN_H_

