//--------------------------------------------------------------
// File     : main.c
//--------------------------------------------------------------

#include "main.h"

int main() {

	/* initialisatie */
	SystemInit();
	init_VGA_API();

    logger (__func__, NOTE_, "Start programma");

    tekst (10, 10, "raha", FONT, CYAAN, STIJL);

    while(1) {

    	/* demo applicatie */
    	leesBuffer();

    }

    return 0;
}
