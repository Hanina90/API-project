//--------------------------------------------------------------
// File     : io_layer.h
//--------------------------------------------------------------

#ifndef IO_layer_H_   
#define IO_layer_H_

#include "main.h"

void init_VGA_API();
void init_UART();

#endif // IO_layer_H_

