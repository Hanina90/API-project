//--------------------------------------------------------------
// File     : main.c
//--------------------------------------------------------------

#include "main.h"

int main() {

	/* initialisatie */
	SystemInit();
	init_VGA_API();

    logger (__func__, NOTE_, "Start programma");

    while(1) {

    	/* demo applicatie */
    	leesBuffer();

    }

    return 0;
}
