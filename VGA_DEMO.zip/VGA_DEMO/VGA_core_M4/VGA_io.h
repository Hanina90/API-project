//--------------------------------------------------------------
// File     : VGA_io.h
//--------------------------------------------------------------

#ifndef VGA_IO_H_   
#define VGA_IO_H_

//--------------------------------------------------------------
// Includes
//--------------------------------------------------------------
#include "VGA_draw.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// aan en uit definieren
#define OFF 0
#define ON  1

typedef enum { false, true } bool; // Bool type maken

/** errorType. */
typedef enum {
    NOTE_,
    WARNING_,
    ERROR_
} errorType;

bool print_error;     
bool print_note;      
bool print_warning; 

/** Error handling functies */
void init_logger( bool errorON, bool warningON, bool noteON );
void set_error_log (bool errorON);
void set_warning_log (bool warningON);
void set_note_log (bool noteON);

void logger (const char* function, const errorType error, const char* message);

/** general functies */
void init_applicatie();
void initaliseer_VGA();
void wacht (int msecs);

#endif // VGA_IO_H_

