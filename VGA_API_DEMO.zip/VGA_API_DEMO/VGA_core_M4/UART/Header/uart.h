/*
Author: 	W Pielage & E Helmond & J.F. van der Bent
Date:		13-9-2015
Revision:	5


    uart.c:
          UART2 driver for SpARM-board v1

    pin-info:
           PA2 - TX
           PA3 - RX

To enable UART use the following line:
	UART_init();
To use UART on interrupt base use:
	UART_INT_init();

This file initialize the UART on the ARM-board v5.
To send data to the UART use:
	UART_printf(*string);

To read the UART without interrupt use:
	char = USART2->DR & 0xFF;

In the interrupt routine the char is send back to the terminal
*/

/****************Libraries******************************/
/* Libraries needed for UART are (These are in main.h):
 * #include "stm32f4xx.h"
 * #include "stm32f4xx_gpio.h"
 * #include "stm32f4xx_usart.h"
 */

/****************Function Prototypes********************/

//================================================================
//#define		RTC1		1
//#define		RTC_SET		1
//#define		AD			1
//#define		DA			1
//#define		BUZZER		1
//#define		LEDS		1
//#define 	SPI			1
//#define 	UART		1
//#define		PWM			1
//#define		LCD			1
//#define		DELAY		1
//#define		KEYS_INT	1
//#define		DFT			1
//
//#include "stm32f4xx.h"
//#include "stm32f4xx_conf.h"
//#include "stm32f4xx_gpio.h"
//#include "stm32f4xx_rcc.h"
//#include "stm32f4xx_syscfg.h"
//#include "stm32f4xx_pwr.h"
//#include "misc.h"
//#include <stdio.h>
//#include <stdarg.h>
//#include <stdint.h>
//
//
//#if UART
//#include "stm32f4xx_usart.h"
//#endif
//
//
//
//
//#define		LED1		GPIOD, GPIO_Pin_12
//#define		LED2		GPIOD, GPIO_Pin_13
//#define		LED3		GPIOD, GPIO_Pin_14
//#define		LED4		GPIOD, GPIO_Pin_15
//
//#define		TOGGLE		2
//#define		ON			1
//#define 	OFF			0
//================================================================

#include "main.h"

#define CR 13 // carriage return char
#define LF 10 // linefeed char


void UART_init(void);
signed int UART_printf(size_t length, const char *pFormat, ...);
void UART_INT_init(void);
void UART_putchar(char c);
void UART_puts(char *s);
void UART_putnum(unsigned int num, unsigned char deel);
void UART_putint(unsigned int num);
char UART_get(void);
void UART_gets(char *s, int echo);



