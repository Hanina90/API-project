//--------------------------------------------------------------
// File     : VGA_draw.c
//--------------------------------------------------------------

#include "VGA_draw.h"
#include "bitmap.h"

#define MAX_LIJNDIKTE 25

int width 	= VGA_DISPLAY_X;
int height 	= VGA_DISPLAY_Y;

/**
 * @brief Coordinaten check: checkt of de coordaten valide zijn.
 *
 * @param x x coordinaat
 * @param y y coordinaat
 * @param width breedte van het VGA scherm
 * @param height hoogte van het VGA scherm
 */

int coordinaten_check (int x, int y, int width, int height ) {

	int out_of_bounds = 0;

    // X is buiten het scherm
    if ( x > width || x < 0 ) {
        logger( __func__, WARNING_, "X Coordinaat is buiten het scherm");
        out_of_bounds = 1;
    }

    // Y is buiten het scherm
    if ( y > height || y < 0 ) {
        logger( __func__, WARNING_, "Y Co0rdinate is buiten het scherm");
        out_of_bounds = 1;
    }

    return out_of_bounds;

}

/**
 * @brief Coordinaten check: checkt of de lijndikte valide is.
 *
 * @param dikte dikte van de lijn
 */
void lijndikte_check (int dikte)
{
    if (dikte > MAX_LIJNDIKTE)
    {
        logger( __func__, WARNING_, "gegeven lijndikte is groter dan maximum lijndikte"); 
        dikte = MAX_LIJNDIKTE;
        logger( __func__, WARNING_, "lijndikte is gelijk aan maximum gemaakt"); 
    }
}

/**
 * @brief set_pixel		teken pixel
 *
 * @param msecs			wachttijd in milliseconden
 */
void set_pixel(int x, int y, kleurType kleur)
{
	int out_of_bounds = coordinaten_check (x, y, width, height); // true wanneer error
	if(!out_of_bounds) UB_VGA_SetPixel(x,y,kleur);
}


/**
 * @brief Lijn: tekent een lijn van een startpunt tot een eindpunt, met een meegegeven dikte
 * 		 en kleur
 * @param x_start 	x coordinaat van startpunt
 * @param y_start 	y coordinaat van startpunt
 * @param x_stop 	x coordinaat van stoppunt
 * @param y_stop 	y coordinaat van stoppunt
 * @param dikte 		dikte van de lijn
 * @param kleur_type kleur van de lijn
 */
void lijn (int x_start, int x_stop, int y_start, int y_stop, int dikte, kleurType kleur)
{
    // coordinaten check:
    logger( __func__, NOTE_, "Check start coordinaten"); 
    coordinaten_check (x_start, y_start, width, height );

    logger( __func__, NOTE_, "Check stop coordinaten"); 
    coordinaten_check (x_stop, y_stop, width, height );

    // lijndikte check:
    lijndikte_check (dikte);

    float x, y;

    //tekenen van x_start naar x_stop
	if (x_stop > x_start)
		for (int x = x_start; (x <= x_stop); x++)
			for (int i = 0; i < dikte; i++)
			{
				y = ((y_stop - y_start)/ (x_stop - x_start))* (x - x_start) + y_start;
				set_pixel(x, y, kleur);
			}
	//tekenen van x_stop naar x_start
	if (x_stop < x_start)
		for (int x = x_stop; (x <= x_start); x++)
			for (int i = 0; i < dikte; i++)
			{
				y = ((y_stop - y_start)/ (x_stop - x_start))* (x - x_start) + y_start;
				set_pixel(x,(y+i), kleur);
			}
	//tekenen van y_start naar y_stop
	if (x_start == x_stop && y_stop > y_start)
		for (int y = y_start; (y <= y_stop); y++)
			for (int i = 0; i < dikte; i++)
			{
				x = x_start;
				set_pixel(x,(y+i), kleur);
			}
	//tekenen van y_stop naar y_start
	if (x_start == x_stop && y_stop < y_start)
		for (int y = y_stop; (y <= y_start); y++)
			for (int i = 0; i < dikte; i++)
			{
				x = x_start;
				set_pixel(x,(y+i), kleur);
			}

    logger( __func__, NOTE_, "Klaar met lijn tekenen");
}

/**
 * @brief ellipse: 	tekent een ellips
 *
 * @param x_mp 		x coordinaat van middeppunt
 * @param y_mp 		y coordinaat van middelpunt
 * @param radius_x 	x radius
 * @param radius_y 	y radius
 *
 * @param kleur  	kleur van de ellipse
 */
void ellipse (int x_mp, int y_mp, int radius_x, int radius_y, kleurType kleur)
{
    // coordinaten check:
    logger( __func__, NOTE_, "Check center coordinaten"); 
    coordinaten_check (x_mp, x_mp, width, height );

    int hh;
    int ww;
    int hhww;
    int x0;
    int dx = 0;

    hh = radius_y * radius_y;
    ww = radius_x * radius_x;
    hhww = hh * ww;
    x0 = radius_x;

    // teken de horizontale diameter
    for (int x = -radius_x; x <= radius_x; x++)
    	set_pixel(x_mp + x, y_mp, kleur);


    // doe nu beide helften tegelijkertijd, weg van de diameter
    for (int y = 1; y <= radius_y; y++) {
    	int x1 = x0 - (dx - 1);
    	for ( ; x1 > 0; x1--)
    		if (x1*x1*hh + y*y*ww <= hhww)
				break;

    	dx = x0 - x1;  // huidige benadering van de helling
    	x0 = x1;

    	for (int x = -x0; x <= x0; x++)
    	{
    		set_pixel(x_mp + x,y_mp - y, kleur);
    		set_pixel(x_mp + x,y_mp + y, kleur);
    	}
    }

    logger( __func__, NOTE_, "Klaar met ellips tekenen");
}

/**
 * @brief Rechthoek	tekent een rechthoek
 *
 * @param x_lo 		x links onder
 * @param y_lo 		y links onder
 * @param x_rb 		x rechtsboven
 * @param y_rb 		y rechtsboven
 * @param kleur  	kleur van de rechthoek
 */
void rechthoek (int x_lo, int y_lo, int x_rb, int y_rb, kleurType kleur)
{
    // coordinaten check:
    logger( __func__, NOTE_, "Check x_lo en y_lo coordinaten"); 
    coordinaten_check (x_lo, y_lo, width, height );

    logger( __func__, NOTE_, "Check x_rb en y_rb coordinaten"); 
    coordinaten_check (x_rb, y_rb, width, height );
 
    //x1,y1 to x2,y1  en  x1,y2 to x2,y2
    if (x_rb > x_lo)
    	for (int x = x_lo; (x <= x_rb); x++)
    	{
    		float y_onder = ((y_lo - y_lo) / (x_rb - x_lo))* (x - x_lo) + y_lo;
    		set_pixel(x,(y_onder), kleur);
    		float y_boven = ((y_rb - y_rb) / (x_rb - x_lo))* (x - x_lo) + y_rb;
    		set_pixel(x,(y_boven), kleur);
    	}

    else
    	for(int x = x_rb; (x <= x_lo); x++)
    	{
    		float y_onder = ((y_lo - y_lo)/ (x_rb - x_lo))* (x - x_lo) + y_lo;
    		set_pixel(x,(y_onder), kleur);
    		float y_boven = ((y_rb - y_rb)/ (x_rb- x_lo))* (x - x_lo) + y_rb;
    		set_pixel(x,(y_boven), kleur);
    	}

    //x1,y1 to x1,y2  en  x2,y1 to x2,y2
    if (y_rb > y_lo)
    	for(int y = y_lo; (y < (y_rb)); y++)
    	{
    		float  x_re = x_lo;
    		set_pixel((x_re),(y), kleur);
    		float x_li = x_rb;
    		set_pixel((x_li),(y), kleur);
    	}

    else
    	for(int y = y_rb; (y < (y_lo)); y++)
    	{
    		float  x_re = x_lo;
    		set_pixel((x_re),(y), kleur);
    		float x_li = x_rb;
    		set_pixel((x_li),(y), kleur);
    	}

    logger( __func__, NOTE_, "Klaar met rechthoek tekenen");

}

/**
 * @brief Driehoek	tekent een driehoek
 *
 * @param x1			x hoek 1
 * @param y1 		y hoek 1
 * @param x2 		x hoek 2
 * @param y2 		y hoek 2
 * @param x3 		x hoek 3
 * @param y3 		y hoek 3
 * @param kleur  	kleur van de driehoek
 */
void driehoek (float x1, float y1, float x2, float y2, float x3, float y3, kleurType kleur)
{
    // coordinaten check:
    logger( __func__, NOTE_, "Check x1 en y1 coordinaten"); 
    coordinaten_check (x1, y1, width, height );

    logger( __func__, NOTE_, "Check x2 en y2 coordinaten"); 
    coordinaten_check (x2, y2, width, height );

    logger( __func__, NOTE_, "Check x3 en y3 coordinaten"); 
    coordinaten_check (x3, y3, width, height );


    //Lijn van x1 naar x2
	    if (x2 > x1)
	   		  for(int x = x1; (x <= x2); x++)
	   		  {
	   			  float y = ((y2 - y1)/ (x2- x1))* (x - x1) + y1;
	   			  set_pixel(x,y,kleur);
	   		  }

	   	  if (x2 < x1)
	   		  for(int x = x2; (x <= x1); x++)
	   		  {
	   			  float y = ((y2 - y1)/ (x2 - x1))* (x - x1) + y1;
	   			  set_pixel(x,y,kleur);
	   		  }

	   	  if (x1 == x2 && y2 > y1)
	   		  for(int y = y1; (y <= y2); y++)
	   		  {
	   			  float  x = x1;
	   			  set_pixel(x,y,kleur);
	   		  }

	   	  if (x1 == x2 && y2 < y1)
	   	  	  for(int y = y2; (y <= y1); y++)
	   	  	  {
	   	  		  float  x = x1;
	   	  		  set_pixel(x,y,kleur);
	   	  	  }

	   	 //Lijn van x2 naar x3
	   	 if (x3 > x2)
			  for(int x = x2; (x <= x3); x++)
			  {
				  float y = ((y3 - y2)/ (x3 - x2))* (x - x2) + y2;
				  set_pixel(x, y, kleur);
			  }

		  if (x3 < x2)
			  for(int x = x3; (x <= x2); x++)
			  {
				  float y = ((y3 - y2)/ (x3 - x2))* (x - x2) + y2;
				  set_pixel(x, y, kleur);
			  }

		  if (x2 == x3 && y3 > y2)
			  for(int y = y2; (y <= y3); y++)
			  {
				  float  x = x2;
				  set_pixel(x, y, kleur);
			  }

		  if (x2 == x3 && y3 < y2)
			  for(int y = y3; (y <= y2); y++)
			  {
				  float  x = x2;
				  set_pixel(x, y, kleur);
			  }

		  //Lijn van x1 naar x3
		  if (x3 > x1)
			  for(int x = x1; (x <= x3); x++)
			  {
				  float y = ((y3 - y1)/ (x3 - x1))* (x - x1) + y1;
				  set_pixel(x, y, kleur);
			  }

		  if (x3 < x1)
			  for(int x = x3; (x <= x1); x++)
			  {
				  float y = ((y3 - y1)/ (x3 - x1))* (x - x1) + y1;
				  set_pixel(x, y, kleur);
			  }

		  if (x1 == x3 && y3 > y1)
			  for(int y = y1; (y <= y3); y++)
			  {
				  float  x = x1;
				  set_pixel(x, y, kleur);
			  }

		  if (x1 == x3 && y3 < y1)
			  for(int y = y3; (y <= y1); y++)
			  {
				  float  x = x1;
				  set_pixel(x ,y, kleur);
			  }

    logger( __func__, NOTE_, "Klaar met rechthoek tekenen");

}

/**
 * @brief drawletter		tekent een tekst
 *
 * @param x
 * @param y
 * @param letter nummer
 * @param kleur		kleur van de tekst
 */
void draw_letter (int input_x, int input_y, unsigned char letter, int kleur)
{

  for (int y =0; y<8; y++)
	  for (int x =0; x<8; x++)
	  {
		  int byte =  font8x8_basic[letter][y];
		  if(byte >> x & 0x01) set_pixel(input_x + x ,input_y + y, kleur);
	  }
}

/**
 * @brief Tekst		tekent een tekst
 *
 * @param x			x coordinaat
 * @param y			y coordinaat
 * @param tekst		input tekst
 * @param fontnaam	input font
 * @param kleur		kleur van de tekst
 * @param stijl		stijl van de tekst
 */
void tekst (int x, int y, const char* tekst, fontType fontnaam, kleurType kleur, stijlType stijl)
{
    // coordinaten check:
    logger( __func__, NOTE_, "Check x en y coordinaten"); 
    coordinaten_check (x, y, width, height );

    int tekst_length = strlen(tekst);
    int x_pos = 0;

    for( int i=0; i<tekst_length; i++)
    {
    	int letter_num = (int)tekst[i] - 32;

    	draw_letter (x + x_pos, y, letter_num, kleur);
    	x_pos += BITMAP_SIZE;
    }

    logger( __func__, NOTE_, "Klaar met tekst tekenen");

}

/**
 * @brief bitmap	tekent een bitmap
 *
 * @param nr		bitmap nummer
 * @param x			x coordinaat
 * @param y			y coordinaat
 */
void bitmap (int nr, int x_lo, int y_lo)
{
    // coordinaten check:    
    logger( __func__, NOTE_, "Check x_lo en y_lo coordinaten"); 
    coordinaten_check (x_lo, y_lo, width, height );

    int color;
    for (int i=0; i<BITMAP_SIZE; i++)
    	for (int j=0; j<BITMAP_SIZE; j++)
    		{
				switch (nr)
				{
					//Pijl boven
					case 1:
						color = pijl_boven[i][j];
						if (color == 0x01) set_pixel((i+x_lo), (j+y_lo) , 0);

					break;

					//Pijl onder
					case 2:
						color = pijl_onder[i][j];
						if (color == 0x01) set_pixel((i+x_lo), (j+y_lo) ,0);
					break;

					//Pijl rechts
					case 3:

						color = pijl_links[i][j];
						if (color == 0x01) set_pixel((i+x_lo), (j+y_lo) , 0);
					break;

					//Pijl links
					case 4:
						color = pijl_rechts[i][j];
						if (color == 0x01) set_pixel((i+x_lo), (j+y_lo) , 0);
					break;

					//Smiley_blij
					case 5:
						color = smiley_blij[i][j];
						if (color == 0x01) set_pixel((i+x_lo), (j+y_lo) , 0);
						else if (color == 0x00) set_pixel((i+x_lo), (j+y_lo) , VGA_COL_YELLOW);
						else if (color == 0x02) set_pixel((i+x_lo), (j+y_lo) , VGA_COL_RED);
						else set_pixel((i+x_lo), (j+y_lo) , WIT);
					break;

					//Smiley_boos
					case 6:
						color = smiley_boos[i][j];
						if (color == 0x01) set_pixel((i+x_lo), (j+y_lo) , 0);
						else if (color == 0x00) set_pixel((i+x_lo), (j+y_lo) , 200);
						else set_pixel((i+x_lo), (j+y_lo) , WIT);
					break;

					//Letter A
					case 7:
						color = A [j][i];
						if (color == 0x01) set_pixel((i+x_lo), (j+y_lo),VGA_COL_BLACK);
					break;

					//Letter B
					case 8:
						color = B [j][i];
						if (color == 0x01) set_pixel((i+x_lo), (j+y_lo),VGA_COL_BLACK);
					break;

					//Letter C
					case 9:
						color = C [j][i];
						if (color == 0x01) set_pixel((i+x_lo), (j+y_lo),VGA_COL_BLACK);
					break;
				}

			}

    logger( __func__, NOTE_, "Klaar met bitmap tekenen");

}

/**
 * @brief clearscherm	vult het scherm met een kleur
 *
 * @param kleur  		kleur van het scherm
 */
void clearscherm (kleurType kleur)
{
    logger( __func__, NOTE_, "clearscreen.");
    UB_VGA_FillScreen(kleur);
    logger( __func__, NOTE_, "Klaar met scherm vullen");
}






