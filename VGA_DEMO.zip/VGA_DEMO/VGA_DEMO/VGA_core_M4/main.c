#include "main.h"

int main() {

	SystemInit();
	init_VGA_API();

	UB_VGA_Screen_Init();

    logger (__func__, NOTE_, "Start programma");

    while(1) {

    	leesBuffer();

    }

    return 0;
}
