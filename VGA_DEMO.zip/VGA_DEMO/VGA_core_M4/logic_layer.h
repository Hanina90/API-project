//--------------------------------------------------------------
// File     : io_layer.h
//--------------------------------------------------------------

#ifndef logic_layer_H_   
#define logic_layer_H_
   
#include "main.h"

void input_afhandeling ();

#endif // logic_layer_H_   
