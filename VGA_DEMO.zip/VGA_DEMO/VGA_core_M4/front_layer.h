#ifndef front_layer_H_   
#define front_layer_H_

#include "main.h"

#define MAX_NUM_OF_WORDS 20
#define COMMAND 0
#define WACHTTIJD 1
#define STIJL 7

struct user_input;

struct user_input {

    commandType command;
    int x_start, y_start, x_stop, y_stop, dikte; //lijn
    int x_mp, y_mp, radius_x, radius_y;
    int x_lo, y_lo, x_rb, y_rb;
    int x1, y1, x2, y2, x3, y3;
    int x, y;
    int nr;
    int wachttijd; 
    char*		input_tekst;
    kleurType   input_kleur;
    stijlType   input_stijl;

} user_input;


/* Get functions */
void getCommand     (char** inputString);
void getColor       (char** inputColor);
void getStijl       (char* inputString );

/* Debug */
void printCommand   ();

/* lees buffer */
void input_INIT		();
void leesBuffer     ();



#endif // front_layer_H_

