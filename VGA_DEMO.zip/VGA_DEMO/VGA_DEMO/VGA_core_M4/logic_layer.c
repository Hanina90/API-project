#include "logic_layer.h"

/**
 * @brief getCommand 	Uitvoeren van de ingevoerde opdracht
 *
 *
 */
void input_afhandeling () {
    
    kleurType kleur = user_input.input_kleur;    

    logger (__func__, NOTE_, "Input verwerken");

    // voer command uit 
    switch ( user_input.command ) {
        
        case LIJN:
            logger (__func__, NOTE_, "Teken lijn");

            lijn (  user_input.x_start, user_input.x_stop,
            		user_input.y_start, user_input.y_stop, user_input.dikte, kleur);
            break;

        case ELLIPSE:
            logger (__func__, NOTE_, "Teken ellipse");
            ellipse (   user_input.x_mp, user_input.y_mp, 
                        user_input.radius_x, user_input.radius_y, kleur);
            break;

        case RECHTHOEK:
            logger (__func__, NOTE_, "Teken rechthoek");
            rechthoek ( user_input.x_lo, user_input.y_lo, 
                        user_input.x_rb, user_input.y_rb, kleur);
            break;

        case DRIEHOEK:
            logger (__func__, NOTE_, "Teken driehoek");
            driehoek (  user_input.x1, user_input.y1,
                        user_input.x2, user_input.y2,  
                        user_input.x3, user_input.y3,  kleur);
            break;

        case TEKST:
            logger (__func__, NOTE_, "Teken tekst");
            tekst (user_input.x, user_input.y, user_input.input_tekst, FONT, kleur, NORMAL);
            break;

        case BITMAP:
            logger (__func__, NOTE_, "Teken bitmap");
            bitmap (user_input.nr, user_input.x_lo, user_input.y_lo); 
            break;

        case WACHT:
            logger (__func__, NOTE_, "Wacht");
            wacht (100); 
            break;

        case CLEARSCHERM:
            logger (__func__, NOTE_, "Clearscherm");
            clearscherm (kleur);
            break;

        case NONE:
            logger (__func__, NOTE_, "Nothing to do");
            break;

        default:
            logger (__func__, WARNING_, "Geen herkenbaar command");           
    }
}

    
    
            


