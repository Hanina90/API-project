#include "front_layer.h"

/*
 * @brief   Print command (NOTE: wordt alleen gebruikt voor debug) TODO: (re)move
 */
/*
void printCommand () {

    char *given_command, *given_color;                   

    logger (__func__, NOTE_, "Print command");

    printf( "\t ============================\n");

    switch ( user_input.command ) {
        
        case LIJN:          given_command = "LIJN";         break;
        case ELLIPSE:       given_command = "ELLIPSE";      break;
        case RECHTHOEK:     given_command = "RECHTHOEK";    break;
        case DRIEHOEK:      given_command = "DRIEHOEK";     break;
        case TEKST:         given_command = "TEKST";        break;
        case BITMAP:        given_command = "BITMAP";       break;
        case WACHT:         given_command = "WACHT";        break;
        case CLEARSCHERM:   given_command = "CLEARSCHERM";  break;
        case NONE:          given_command = "NONE";         break;
        default: given_command = "Waarschijnlijk NULL";
          
    }

    printf( "\t command:\t %s\n", given_command ); 

    switch ( user_input.input_kleur ) {
        
        case ZWART:         given_color = "ZWART";          break;
        case BLAUW:         given_color = "BLAUW";          break;
        case LICHTBLAUW:    given_color = "LICHTBLAUW";     break;
        case GROEN:         given_color = "GROEN";          break;
        case LICHTGROEN:    given_color = "LICHTGROEN";     break;
        case CYAAN:         given_color = "CYAAN";          break;
        case LICHTCYAAN:    given_color = "LICHTCYAAN";     break;
        case ROOD:          given_color = "ROOD";           break;
        case LICHTROOD:     given_color = "LICHTROOD";      break;
        case MAGENTA:       given_color = "MAGENTA";        break;
        case LICHTMAGENTA:  given_color = "LICHTMAGENTA";   break;
        case BRUIN:         given_color = "BRUIN";          break;
        case GEEL:          given_color = "GEEL";           break;
        case GRIJS:         given_color = "GRIJS";          break;
        case WIT:           given_color = "WIT";            break;
         
    }

    printf( "\t color:\t\t %s\n", given_color );

    printf( "\t x_start:\t\t %u\n", user_input.x_start );
    printf( "\t y_start:\t\t %u\n", user_input.y_start );
    printf( "\t x_stop: \t\t %u\n", user_input.x_stop  );
    printf( "\t x_stop: \t\t %u\n", user_input.y_stop  );

    printf( "\t x_mp:     \t\t %u\n", user_input.x_mp );
    printf( "\t y_mp:     \t\t %u\n", user_input.y_mp );
    printf( "\t radius_x: \t\t %u\n", user_input.radius_x );
    printf( "\t radius_y: \t\t %u\n", user_input.radius_y );

    printf( "\t x_lo:     \t\t %u\n", user_input.x_lo );
    printf( "\t y_lo:     \t\t %u\n", user_input.y_lo );
    printf( "\t x_rb:     \t\t %u\n", user_input.x_rb );
    printf( "\t y_rb:     \t\t %u\n", user_input.y_rb );

    printf( "\t x1:     \t\t %u\n", user_input.x1 );
    printf( "\t y1:     \t\t %u\n", user_input.y1 );
    printf( "\t x2:     \t\t %u\n", user_input.x2 );
    printf( "\t y2:     \t\t %u\n", user_input.y2 );
    printf( "\t x3:     \t\t %u\n", user_input.x3 );
    printf( "\t y3:     \t\t %u\n", user_input.y3 );

    printf( "\t x:     \t\t %u\n", user_input.x );
    printf( "\t y:     \t\t %u\n", user_input.y );

    printf( "\t nr:    \t\t %u\n", user_input.nr );
    printf( "\t wachttijd:\t\t %u\n", user_input.wachttijd );

    printf( "\t ============================\n");
 
} 
*/

/**
 * Brief:  input_INIT	initialisatie van input struct
 */
void input_INIT () {

	user_input.x_start 	= 0;
	user_input.x_stop 	= 0;
	user_input.y_start	= 0;
	user_input.y_stop	= 0;

	user_input.x_mp		= 0;
	user_input.y_mp 	= 0;
	user_input.radius_x = 0;
	user_input.radius_y = 0;

	user_input.x_lo		= 0;
	user_input.y_lo 	= 0;
	user_input.x_rb		= 0;
	user_input.y_rb		= 0;

	user_input.x1		= 0;
	user_input.y1		= 0;
	user_input.x2		= 0;
	user_input.y2		= 0;
	user_input.x3		= 0;
	user_input.y3		= 0;
	user_input.x		= 0;
	user_input.y		= 0;

	user_input.nr		   = 0;
	user_input.wachttijd   = 0;
	user_input.input_kleur = 0;
	user_input.input_stijl = 0;
}

/**
 * @brief leesBuffer leest buffer van uart
 */
void leesBuffer () { 
 
	input_INIT ();
	char input_string[INPUT_STR_SIZE];
	logger (__func__, NOTE_, "Verkrijg user input");

	UART_gets(input_string, 0);

	logger (__func__, NOTE_, "User input verkregen");

	UART_puts(input_string); // print input opdracht
	UART_puts("\r");
	UART_puts("\r");

	// input string in losse worden splitten
    char* word;
    const char s[2] = ",";
    char* words[MAX_NUM_OF_WORDS] = {NULL};

    logger (__func__, NOTE_, "Split buffer in woorden");
    
    // eerste woord splitten
    word = strtok(input_string, s); // TODO: spaties eruit halen (nog niet nodig)

    // rest van de woorden splitten en opslaan in words[]
    int i = 0;
    while (word != NULL)
    {
        words[i++] = word;
        word = strtok (NULL, s);
    }
   
    getCommand (words);
    
    //printCommand (); TODO: remove

    // input is verwerkt en het command kan afgehandeld worden
    input_afhandeling ();    
 
}

/**
 * @brief getCommand 	Verkrijgen van opdracht
 *
 * @param inputString	Ingevoerde string
 *
 */
void getCommand (char** inputString) {

    char** inputString_ = inputString; // TODO: niet zo mooi, moet beter kunnen

    char* inputCommand = inputString[COMMAND];

    logger (__func__, NOTE_, "Verkrijgen van command");

    // Aanwezigheid van command checken 
    if (inputCommand == NULL) 
        logger (__func__, ERROR_, "Geen command meegegeven");

    // Command is ingevoerd:
    if 		(strcasecmp(inputCommand, "lijn") == 0) {
    	user_input.command  = LIJN;
        getColor (inputString_);

        // coordinaten verkrijgen
        user_input.x_start  = atoi(inputString[1]);
        user_input.x_stop   = atoi(inputString[2]);
        user_input.y_start  = atoi(inputString[3]);
        user_input.y_stop   = atoi(inputString[4]);

        // verkrijgen lijndikte
        user_input.dikte	= atoi(inputString[5]);

    }
    else if (strcasecmp(inputCommand, "ellips") == 0) {
    	user_input.command = ELLIPSE;
    	getColor (inputString_);

    	// coordinaten verkrijgen
    	user_input.x_mp     = atoi(inputString[1]);
    	user_input.y_mp     = atoi(inputString[2]);

    	// radius
    	user_input.radius_x = atoi(inputString[3]);
    	user_input.radius_y = atoi(inputString[4]);

    }
    else if (strcasecmp(inputCommand, "rechthoek") == 0) {
    	user_input.command = RECHTHOEK;
    	getColor (inputString_);

    	// coordinaten verkrijgen
    	user_input.x_lo = atoi(inputString[1]);
    	user_input.y_lo = atoi(inputString[2]);
    	user_input.x_rb = atoi(inputString[3]);
    	user_input.y_rb = atoi(inputString[4]);
    }
    else if (strcasecmp(inputCommand, "driehoek") == 0) {
    	user_input.command = DRIEHOEK;
    	getColor (inputString_);

    	// coordinaten verkrijgen
    	user_input.x1 = atoi(inputString[1]);
    	user_input.y1 = atoi(inputString[2]);
    	user_input.x2 = atoi(inputString[3]);
    	user_input.y2 = atoi(inputString[4]);
    	user_input.x3 = atoi(inputString[5]);
    	user_input.y3 = atoi(inputString[6]);
    }
    else if (strcasecmp(inputCommand, "tekst") == 0) {
    	user_input.command = TEKST;
    	getColor (inputString_);

    	// coordinaten verkrijgen
    	user_input.x = atoi(inputString[1]);
    	user_input.y = atoi(inputString[2]);

    	// input tekst
    	user_input.input_tekst = inputString[3];

    	getStijl (inputString[STIJL]);
    }

    else if (strcasecmp(inputCommand, "bitmap") == 0) {
    	user_input.command = BITMAP;
                    
    	// bitmap nummer verkrijgen
    	user_input.nr   = atoi(inputString[1]);

    	// coordinaten verkrijgen
    	user_input.x_lo = atoi(inputString[2]);
    	user_input.y_lo = atoi(inputString[3]);

    }

    else if (strcasecmp(inputCommand, "wacht") == 0) {
    	user_input.command = WACHT;
    	user_input.wachttijd = atoi(inputString[WACHTTIJD]);
    }

    else if (strcasecmp(inputCommand, "clearscherm") == 0 ) {
    	user_input.command = CLEARSCHERM;
    	getColor (inputString_);
    }

    else if (strcasecmp(inputCommand, "setErrorLevel") == 0 ) {
    	user_input.command = SETERRORLEVEL;
    	user_input.errorLevel = atoi(inputString[1]);
    }

    else {
        // negeer command
        logger (__func__, NOTE_, "Command wordt niet herkend/ondersteund dus negeer");
        user_input.command = NONE;
    }

}

/**
 * @brief getColor 		Verkrijgen van de kleur
 *
 * @param inputString	Ingevoerde string
 *
 */
void getColor (char** inputString) {

    unsigned char COLOR_INDEX;
    char* inputColor;

    logger (__func__, NOTE_, "Verkrijgen van kleur"); 

    // bereken positie van kleur in array words
    switch ( user_input.command ) {
        
        // index van waar kleur zich zou moeten bevinden
        case LIJN:          COLOR_INDEX = 6;  break;
        case ELLIPSE:       COLOR_INDEX = 5;  break;
        case RECHTHOEK:     COLOR_INDEX = 5;  break;
        case DRIEHOEK:      COLOR_INDEX = 7;  break;
        case TEKST:         COLOR_INDEX = 4;  break;
        case CLEARSCHERM:   COLOR_INDEX = 1;  break;
        default:
        	 logger (__func__, ERROR_, "Geen kleur herkend");
    
    }

    inputColor = inputString[COLOR_INDEX];

    // Command is ingevoerd:
    if 		(strcasecmp(inputColor, "zwart") == 0 )
    		user_input.input_kleur = ZWART;

    else if (strcasecmp(inputColor, "blauw") == 0 )
    		user_input.input_kleur = BLAUW;

    else if (strcasecmp(inputColor, "lichtblauw") == 0 )
    		user_input.input_kleur = LICHTBLAUW;

    else if (strcasecmp(inputColor, "groen") == 0 )
    		user_input.input_kleur = GROEN;

    else if (strcasecmp(inputColor, "lichtgroen") == 0 )
    		user_input.input_kleur = LICHTGROEN;

    else if (strcasecmp(inputColor, "cyaan") == 0 )
    		user_input.input_kleur = CYAAN;

    else if (strcasecmp(inputColor, "lichtcyaan") == 0 )
    		user_input.input_kleur = LICHTCYAAN;

    else if (strcasecmp(inputColor, "rood") == 0 )
    		user_input.input_kleur = ROOD;

    else if (strcasecmp(inputColor, "lichtrood") == 0 )
            user_input.input_kleur = LICHTROOD;

    else if (strcasecmp(inputColor, "magenta") == 0 )
            user_input.input_kleur = MAGENTA;

    else if (strcasecmp(inputColor, "lichtmagenta") == 0 )
          	user_input.input_kleur = LICHTMAGENTA;

    else if (strcasecmp(inputColor, "bruin") == 0 )
          	user_input.input_kleur = BRUIN;

    else if (strcasecmp(inputColor, "geel") == 0 )
          	user_input.input_kleur = GEEL;

    else if (strcasecmp(inputColor, "grijs") == 0 )
          	user_input.input_kleur = GRIJS;

    else if (strcasecmp(inputColor, "wit") == 0 )
        	user_input.input_kleur = WIT;

    else
        // negeer command
        logger (__func__, WARNING_, "Kleur wordt niet herkend/ondersteund");

}

/**
 * @brief getCommand 	Verkrijgen van stijl
 *
 * @param inputString	Ingevoerde string
 *
 */
void getStijl ( char* inputString ) {

    if      (strcasecmp(inputString, "normal") == 0 )
                    user_input.input_stijl = NORMAL;

    else if (strcasecmp(inputString, "italic") == 0 )
                    user_input.input_stijl = ITALIC;

    else if (strcasecmp(inputString, "bold") == 0 )
                    user_input.input_stijl = BOLD;

}




